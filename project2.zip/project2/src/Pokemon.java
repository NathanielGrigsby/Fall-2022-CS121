public class Pokemon {
    public String name;
    public int hitPoints;
    public String move;
    public int movePower;
    public int attackSpeed;
    public Pokemon(){}
    public Pokemon(String name, int hitPoints, String move, int movePower, int attackSpeed){
        this.name = name;
        this.hitPoints = hitPoints;
        this.move = move;
        this.movePower = movePower;
        this.attackSpeed = attackSpeed;
    }
    //public String displayPokemonStats(Object p){
    public String displayPokemonStats(){
        String stats = "Name: " + name + "\nHit Points: " + hitPoints + "\nMove: " + move + "\nMove Power: " + movePower + "\nAttack Speed: " + attackSpeed;
        return stats;
    }
}