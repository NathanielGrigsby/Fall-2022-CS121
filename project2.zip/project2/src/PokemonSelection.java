import java.util.Scanner;
public class PokemonSelection {
    static Scanner scanner = new Scanner(System.in);
    //public Pokemon
    // public Object createPokemon(){
    public Pokemon createPokemon(){
        String name = scanner.nextLine();
        System.out.println("HP: ");
        int hitPoints = Integer.parseInt(scanner.nextLine());
        System.out.println("Move: ");
        String move = scanner.nextLine();
        System.out.println("Move power: ");
        int movePower = Integer.parseInt(scanner.nextLine());
        System.out.println("Speed: ");
        int attackSpeed = Integer.parseInt(scanner.nextLine());
        Pokemon p = new Pokemon(name, hitPoints, move, movePower, attackSpeed);
        return p;
    }
    public void assignPokemon(){
        Pokemon p = new Pokemon();
        System.out.println("Player 1: Select a Pokemon and enter its stats");
        Pokemon pokemon1 = createPokemon();
        System.out.println("Player 2: Select a Pokemon and enter its stats");
        Pokemon pokemon2 = createPokemon();
        System.out.printf("Player 1 Pokemon:\n" + pokemon1.displayPokemonStats());
        System.out.printf("\nPlayer 2 Pokemon:\n" + pokemon2.displayPokemonStats());
    }
}
